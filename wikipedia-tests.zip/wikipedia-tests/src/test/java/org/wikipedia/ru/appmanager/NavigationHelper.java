package org.wikipedia.ru.appmanager;

public class NavigationHelper {
}
