package org.wikipedia.ru.model;

public class SimpleSearch {
}
